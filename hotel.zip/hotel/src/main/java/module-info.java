module rl.hotel {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.jfoenix;
    requires java.sql;

    opens rl.hotel to javafx.fxml;
    exports rl.hotel;
}